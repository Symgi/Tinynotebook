CKEDITOR.plugins.setLang('imgur', 'zh', {
    clientIdMissing: '請加入config.imgurClientID到您的設定檔',
    uploading: '張圖片正在上傳中...',
    failToUpload: '上傳失敗:'
});
